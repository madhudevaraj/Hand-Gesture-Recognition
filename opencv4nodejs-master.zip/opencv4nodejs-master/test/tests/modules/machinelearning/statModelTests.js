const cv = global.dut;
const { expect } = require('chai');

module.exports = () => {
  describe('StatModel', () => {
    describe('constructor', () => {
      it('should be constructable with default args', () => {

      });
    });
  });
};
