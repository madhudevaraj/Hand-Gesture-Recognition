#include "macros.h"
#include <opencv2/core.hpp>
#include <opencv2/video.hpp>

#ifndef __FF_VIDEO_H__
#define __FF_VIDEO_H__

class Video {
public:
  static NAN_MODULE_INIT(Init);
};

#endif