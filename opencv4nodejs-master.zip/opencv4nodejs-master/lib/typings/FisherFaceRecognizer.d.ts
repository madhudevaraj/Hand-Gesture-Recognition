import { FaceRecognizer } from './FaceRecognizer';

export class FisherFaceRecognizer extends FaceRecognizer {
  constructor(num_components?: number, threshold?: number);
}
