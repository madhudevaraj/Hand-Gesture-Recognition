export class Moments {
  readonly m00: number;
  readonly m10: number;
  readonly m01: number;
  readonly m20: number;
  readonly m11: number;
  readonly m02: number;
  readonly m30: number;
  readonly m21: number;
  readonly m12: number;
  readonly m03: number;
  readonly mu20: number;
  readonly mu11: number;
  readonly mu02: number;
  readonly mu30: number;
  readonly mu21: number;
  readonly mu12: number;
  readonly mu03: number;
  readonly nu20: number;
  readonly nu11: number;
  readonly nu02: number;
  readonly nu30: number;
  readonly nu21: number;
  readonly nu12: number;
  readonly nu03: number;
  huMoments(): number[];
}
